"""Install (or re-enable) Soulweaver Studio in this Blender and save preferences.

Run by the Soulweaver plugin:
  blender --background --python sw_install.py -- --zip <path>
  blender --background --online-mode --python sw_install.py -- --repo-url <url>
Prints: SW_RESULT {"ok": true, "module": "...", "addon_version": "..."}
     or SW_RESULT {"ok": false, "error": "..."}
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import addon_utils  # noqa: E402
import bpy  # noqa: E402
import sw_common  # noqa: E402

REPO_NAME = "Soulweaver"


def parse_args(args):
    opts = {}
    it = iter(args)
    for a in it:
        if a in ("--zip", "--repo-url"):
            opts[a[2:]] = next(it, None)
        elif a == "--meddle-tools":
            opts["meddle-tools"] = True
    return opts


def install_from_zip(zip_path):
    if not zip_path or not os.path.isfile(zip_path):
        raise RuntimeError("Addon zip not found: %s" % zip_path)
    bpy.ops.extensions.package_install_files(filepath=zip_path, repo="user_default",
                                             enable_on_install=True, overwrite=True)


MEDDLE_TOOLS_REPO = "https://raw.githubusercontent.com/PassiveModding/MeddleTools/refs/heads/main/repo.json"


def install_from_repo(url, pkg_id=sw_common.PKG_ID, name=REPO_NAME):
    repos = bpy.context.preferences.extensions.repos
    index = next((i for i, r in enumerate(repos) if r.use_remote_url and r.remote_url == url), None)
    if index is None:
        bpy.ops.preferences.extension_repo_add(name=name, remote_url=url, type='REMOTE',
                                               use_sync_on_startup=True)
        index = next(i for i, r in enumerate(repos) if r.use_remote_url and r.remote_url == url)
    bpy.ops.extensions.repo_sync(repo_index=index)
    bpy.ops.extensions.package_install(repo_index=index, pkg_id=pkg_id, enable_on_install=True)


def main():
    opts = parse_args(sw_common.script_args())
    # Always (re)install: this also updates an older Soulweaver Studio in place.
    if opts.get("repo-url"):
        install_from_repo(opts["repo-url"])
    else:
        install_from_zip(opts.get("zip"))
    module, _ = sw_common.find_package(bpy)
    if module is None:
        raise RuntimeError("Install finished but Soulweaver Studio wasn't found")
    if module not in bpy.context.preferences.addons:
        addon_utils.enable(module, default_set=True)
    meddle_error = None
    if opts.get("meddle-tools"):
        try:  # MeddleTools from its own repository (Blender keeps it updated); Studio works without it
            install_from_repo(MEDDLE_TOOLS_REPO, pkg_id="meddle_tools", name="MeddleTools")
        except Exception as e:  # noqa: BLE001
            meddle_error = str(e)
    bpy.ops.wm.save_userpref()
    _, pkg_dir = sw_common.find_package(bpy)
    return {"ok": True, "module": module, "addon_version": sw_common.manifest_version(pkg_dir),
            "meddle_tools_error": meddle_error}


try:
    sw_common.result(main())
except Exception as e:
    sw_common.result({"ok": False, "error": str(e)})
