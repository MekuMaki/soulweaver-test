"""Report whether Soulweaver Studio is installed/enabled in this Blender.

Run by the Soulweaver plugin: blender --background --python sw_probe.py
Prints: SW_RESULT {"blender": "...", "installed": bool, "enabled": bool,
                   "addon_version": str|null, "module": str|null}
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import bpy  # noqa: E402
import sw_common  # noqa: E402

try:
    module, pkg_dir = sw_common.find_package(bpy)
    sw_common.result({
        "blender": "%d.%d.%d" % bpy.app.version,
        "installed": module is not None,
        "enabled": module is not None and module in bpy.context.preferences.addons,
        "addon_version": sw_common.manifest_version(pkg_dir) if pkg_dir else None,
        "module": module,
    })
except Exception as e:
    sw_common.result({"blender": "%d.%d.%d" % bpy.app.version, "error": str(e),
                      "installed": False, "enabled": False, "addon_version": None, "module": None})
