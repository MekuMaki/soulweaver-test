"""Build a ready-to-open .blend with the character imported (run in a hidden Blender by the plugin).

  blender --background --python sw_build_scene.py -- --glb <path> --name <character> --out <file.blend>
      [--actor-index 201 --actor-name <name> --placement x,y,z,yaw] [--bone-system fortune|meddle|mekrig]

Run with SOULWEAVER_NO_SERVER=1 so this Blender doesn't take the link port.
Prints SW_PROGRESS <0..1> <step> lines while working, then one SW_RESULT line.
"""
import importlib
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import bpy  # noqa: E402
import sw_common  # noqa: E402


def parse_args(args):
    opts, key = {}, None
    for a in args:
        if a.startswith("--"):
            key = a[2:]
            opts[key] = None
        elif key:
            opts[key] = a
            key = None
    return opts


def progress(fraction, text):
    sys.stdout.write("SW_PROGRESS %.3f %s\n" % (fraction, text))
    sys.stdout.flush()


def main():
    opts = parse_args(sw_common.script_args())
    for required in ("glb", "name", "out"):
        if not opts.get(required):
            raise RuntimeError("Missing --%s" % required)
    module, _ = sw_common.find_package(bpy)
    if module is None:
        raise RuntimeError("Soulweaver Studio isn't installed in this Blender")
    scene_build = importlib.import_module(module + ".scene_build")
    actor_index = int(opts["actor-index"]) if opts.get("actor-index") else None
    placement = None
    if opts.get("placement"):
        x, y, z, yaw = (float(v) for v in opts["placement"].split(","))
        placement = (x, y, z, yaw)
    return scene_build.build_scene(opts["glb"], opts["name"], opts["out"], progress,
                                   actor_index=actor_index, actor_name=opts.get("actor-name"), placement=placement,
                                   bone_system=opts.get("bone-system"),
                                   hidden_weapons=[w for w in (opts.get("hide-weapons") or "").split(",") if w],
                                   actor_id=int(opts["actor-id"]) if opts.get("actor-id") else None,
                                   layout_items=json.loads(opts["layout-items"]) if opts.get("layout-items") else None,
                                   mount="mount" in opts, pbr_maps=opts.get("pbr-maps"))


try:
    sw_common.result(main())
except Exception as e:
    sw_common.result({"ok": False, "error": str(e)})
