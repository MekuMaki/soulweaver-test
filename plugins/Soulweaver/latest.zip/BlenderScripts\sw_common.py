"""Shared helpers for the Soulweaver plugin's background Blender scripts."""
import json
import os
import sys

PKG_ID = "soulweaver_studio"


def result(data: dict) -> None:
    """Print the one line the plugin reads. Always the last thing a script prints."""
    sys.stdout.write("SW_RESULT " + json.dumps(data) + "\n")
    sys.stdout.flush()


def find_package(bpy):
    """Return (module_name, package_dir) of an installed Soulweaver Studio, or (None, None)."""
    for repo in bpy.context.preferences.extensions.repos:
        if not repo.enabled:
            continue
        pkg_dir = os.path.join(repo.directory, PKG_ID)
        if os.path.isfile(os.path.join(pkg_dir, "blender_manifest.toml")):
            return "bl_ext.%s.%s" % (repo.module, PKG_ID), pkg_dir
    return None, None


def manifest_version(pkg_dir):
    import tomllib
    with open(os.path.join(pkg_dir, "blender_manifest.toml"), "rb") as f:
        return tomllib.load(f).get("version")


def script_args():
    argv = sys.argv
    return argv[argv.index("--") + 1:] if "--" in argv else []
